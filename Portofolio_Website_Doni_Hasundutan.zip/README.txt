Panduan Upload ke GitHub Pages:
1. Ekstrak ZIP ini.
2. Buat repositori baru di GitHub (misalnya: doni-hasundutan.github.io).
3. Upload semua file (index.html dan folder assets) ke repositori.
4. Aktifkan GitHub Pages di Settings -> Pages -> Deploy from branch -> main.
5. Situs kamu akan tampil di: https://<username>.github.io/
